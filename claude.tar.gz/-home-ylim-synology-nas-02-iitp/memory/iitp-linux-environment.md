---
name: iitp-linux-environment
description: IITP traffic_llm 프로젝트의 리눅스 실행 환경 — python/venv/데이터 경로와 시스템 python 의 제약
metadata: 
  node_type: memory
  type: project
  originSessionId: 18095d46-5068-472f-adb4-c339e7b4e8b8
  modified: 2026-08-03T04:58:16.708Z
---

2026-08-02 부터 `/home/ylim/synology-nas-02/iitp` (리눅스)에서 작업한다. 이전에는
Windows(`C:\Users\ylim\OneDrive\research\IITP-Columbus`)였다.

**시스템 python 으로는 아무것도 돌지 않는다.** `/usr/bin/python3` 은 3.14.4 인데
pip·ensurepip·venv 가 모두 없고 numpy 도 없다. `python3 -m venv` 는 실패한다
(python3-venv 미설치, sudo 필요).

대신 **`~/.local/bin/uv`** 가 있다. 환경은 이렇게 만들었다.

    ~/.local/bin/uv venv --python 3.12 .venv
    ~/.local/bin/uv pip install --python .venv/bin/python numpy scipy pillow pyproj anthropic

이후 모든 실행은 `.venv/bin/python` 으로 한다 (`python3` 아님).

경로:
- 데이터셋 `/home/ylim/inclab-nas/DeepAccident/DeepAccident_mini`
  (사본: `/home/ylim/synology-nas-02/dataset/DeepAccident/DeepAccident_mini`)
- 실데이터 테스트는 `DEEPACCIDENT_ROOT` 를 위 경로로 줘야 skip 되지 않는다
  (19개). 주지 않으면 조용히 skip 된다.
- **CARLA `.xodr` 지도는 아직 옮겨오지 않았다.** 없으면 도로망이 궤적 합성으로
  폴백되어 차선 수가 하한이 되고 진행방향 확정률이 떨어진다 (README 참조).

Pillow 가 없으면 BEV 가 SVG 로 폴백되고 관련 테스트 3개가 실패한다 — 실패가 아니라
의존성 누락 신호다.
