---
name: default-path-predictor
description: payload 생성 시 기본 경로 예측기는 학습된 WaypointNet(좌표 회귀)이다 — 규칙 기반이 아니다.
metadata: 
  node_type: memory
  type: feedback
  originSessionId: 18095d46-5068-472f-adb4-c339e7b4e8b8
  modified: 2026-08-12T08:38:24.323Z
---

`examples/run_deepaccident.py` 로 LLM payload 를 만들 때 **기본 경로 예측기는 학습된
좌표 회귀 모델**(`out/predict_model/waypointnet_best.pt`, mode=waypoints)이다.
규칙 기반(지도 제약)은 `--no-predictor` 로 명시할 때만 쓴다.

**Why:** 사용자가 "앞으로 계속 waypoint 예측 모델을 기본 예측 모델로 사용해줘" 라고
지시했다. 근거는 같은 시험셋에서 규칙 기반보다 ADE 가 24% 낮고(3.05m 대 4.01m) 후보
집합의 정확도 상한(78.8%)도 넘는다는 실측이다.

**How to apply:** payload 를 재생성할 때 `--predictor` 를 생략하면 자동으로 학습 모델이
쓰인다. 생성 후 `manifest.json` 의 `config.predictor` 가
`waypointnet_best.pt (mode=waypoints)` 인지 확인할 것 — `rule` 이면 모델 파일이 없거나
torch 가 없어 조용히 내려간 것이다(그 이유를 stdout 에 출력한다).

라이브러리 기본값(`PipelineConfig.predictor`)은 **여전히 `None`(규칙 기반)** 이다.
`traffic_llm` 은 torch 없이도 import·동작해야 하므로 패키지 기본값을 학습 모델로 둘 수
없다 — 이 성질은 테스트로 고정돼 있다. 기본값 변경은 CLI 계층에만 적용된다.

waypoints 모드는 궤적 하나를 확률 1.0 으로 내므로 **다중 모드 분포를 잃는다**
("직진 60% / 좌회전 40%" 같은 표현이 사라진다). 분포가 필요한 실험에서는
`--predictor out/predict_model/ranknet_best.pt` 를 쓴다.
